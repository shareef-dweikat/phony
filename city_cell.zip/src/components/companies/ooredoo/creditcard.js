const credit = [
    {
      dis: "",
      price: "10",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890041/Group_342_jrkqel.png",
      ID: "",
    },
  
    {
      dis: "",
      price: "15",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890048/Group_343_vklst0.png",
      ID: "15",
    },
    {
      dis: "",
      price: "20",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890066/Group_341_y9kwsi.png",
      ID: "20",
    },
    {
      dis: "",
      price: "25",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890076/Group_344_cagj0z.png",
      ID: "25",
    },
    {
      dis: "",
      price: "50",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890087/Group_345_dqlzrq.png",
      ID: "50",
    },
    {
      dis: "",
      price: "100",
      url: "https://res.cloudinary.com/dtu4lltbk/image/upload/v1622890095/Group_346_wdxbq4.png",
      ID: "100",
    },
  ];
  export default credit;
  