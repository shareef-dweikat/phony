import en from "./en-US";
import ar from "./ar-SU";
import is from "./is-ISR";

export default {
  ...en,
  ...ar,
  ...is,
};
