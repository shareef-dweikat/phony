export const LOCALES = {
  ENGLISH: "en",
  ARABIC: "ar",
  ISRAEL: "is",
};
