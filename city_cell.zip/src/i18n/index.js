export { default as I18Provider } from "./provider";
export { LOCALES } from "./locales";
